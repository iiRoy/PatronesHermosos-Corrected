'use client';
const Coordinador = () => {
  return <div className=''>Coordinador</div>;
};

export default Coordinador;
